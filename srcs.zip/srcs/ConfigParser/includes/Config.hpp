/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Config.hpp                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mvachon <mvachon@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/01/22 20:24:07 by mvachon           #+#    #+#             */
/*   Updated: 2026/03/26 13:05:46 by mvachon          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef CONFIG_HPP
#define CONFIG_HPP

#include <fcntl.h>
#include <vector>
#include <unistd.h>
#include <string>

class Exception : public std::exception {
    private:
        std::string _message;
    public:
        explicit Exception(const std::string& message) : _message(message) {}
        virtual ~Exception() throw() {}
        virtual const char* what() const throw() {
            return _message.c_str();
        }
};

struct LocationConfig
{
    std::string path;
    std::string root;
    std::string index;
    std::string upload_dir;
    bool autoindex;
    std::vector<std::string> allowed_methods;
    int         redirectCode;
    std::string redirectUrl;
    LocationConfig() : autoindex(false), redirectCode(0){}
};

struct ErrorPage
{
    int index;
    std::string path;
};

struct ServerConfig
{
    ServerConfig();
    int                         port;
    std::string                 host;
    std::string                 root;
    std::string                 index;
    std::string                 upload_dir;
    std::vector<ErrorPage>      error_page;
    long long                   client_max_body_size;
    bool                        autoindex;
    std::vector<std::string>    allowed_methods;
    LocationConfig              defaults; // faut faire
    std::vector<LocationConfig> locations;
};

class Config
{
    private:
        std::vector<std::vector<std::string> > _fileContent;
        std::vector<ServerConfig> _servers;
        std::string _keysServer[9];
        std::string _keysLocation[7];

        void initServerKeys();
        void initLocationKeys();

        void parseServerBlock(size_t *i);
        void parseServerDirective(ServerConfig &server, const std::string &key, 
                                  const std::vector<std::string> &line, size_t j);
        std::string extractValue(const std::vector<std::string> &line, size_t j, 
                                 const std::string &key);
        
        void parseHost(ServerConfig &server, const std::string &value);
        void parsePort(ServerConfig &server, const std::string &value);
        void parseClientMaxBodySize(ServerConfig &server, const std::string &value);
        void parseAutoindex(ServerConfig &server, const std::string &value);
        void parseErrorPage(ServerConfig &server, const std::vector<std::string> &line, size_t j);

        void parseLocationBlock(ServerConfig &server, size_t *i, size_t *j);
        void parseLocationDirective(LocationConfig &location, const std::string &key, 
                                    const std::vector<std::string> &line, size_t j);
        void parseLocationAutoindex(LocationConfig &location, const std::string &value);
        void parseAllowMethods(std::vector<std::string> &allowed_method, const std::vector<std::string> &line, size_t j);

        void validateDuplicatePorts();
        
        int parseConfigFile();

    public:
        Config();
        bool setFile(std::string doc);
        const std::vector<ServerConfig>& getServers() const;
        void printServers();
};

void validateServerConfig(const ServerConfig& server);
std::vector<std::vector<std::string> > splitLinesWords(const std::string &content);
std::string readFile(const std::string& doc);

#endif
